package week_3;

public class Cube {
    public static void main(String [] args){
        int number = 7;
        
        System.out.println("The Cube of "+ number + " is " + Math.pow(7, 3));
    }  
}
