package WEEK_3;

public class Circle {
    public static void main (String [] args){
        double radius = 14;
        double circumference = (2*Math.PI*radius);
        
        System.out.println("Circumference of the Circle is : " + circumference);
    }
}
