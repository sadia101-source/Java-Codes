package week_3;

public class Multiply {
    public static void main(String [] args){
        float a = 12;
        float b = 5;
        
        System.out.println("The product of " + a + " and " + b + " is " + (a*b) + ".");
    } 
}
