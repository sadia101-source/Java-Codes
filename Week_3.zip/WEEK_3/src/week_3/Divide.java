package WEEK_3;

public class Divide {
    public static void main(String [] args){
        double num1 = 66;
        double num2 = 12;
        
        System.out.println("The Quotient when " + num1 + " is divided by " + num2 + " is " + (num1/num2) + ".");
        System.out.println("The Remainder is " + (num1%num2) + ".");
    }
}
