package WEEK_3;

public class Swap_Num {
    public static void main(String [] args){
        int A = 23;
        int B = 12;
        
        int temp = A;
        A = B;
        B = temp;
        
        System.out.println("Value of A: " + A);
        System.out.println("Value of B: " + B);
    }
}
