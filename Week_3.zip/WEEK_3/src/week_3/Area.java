package WEEK_3;

public class Area {
    public static void main(String [] args){
        int length = 20;
        int breadth = 15;
        
        int area = (length*breadth);
        System.out.println("Area of the Rectangle: " + area);
    }
}