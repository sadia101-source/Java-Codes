package week_3;

public class Average {
    public static void main(String[] args) {
        double a = 56;
        double b = 34;
        double c = 60;
        
        double avg = (a+b+c)/3.0;
        System.out.println("Average = " + avg);
    }
}
